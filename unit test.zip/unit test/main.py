
def foo(x):
    if type(x) not in [int, float]:
        raise TypeError('должно быть число!!!')
    return 1/(1+x)

r_list = [2,0,-3,2+3j, True, [2], 'seven']
massage = 'сумма чисел {x} --> {result}'

for i in r_list:
    s = foo(i)
    print(massage.format(x = i, result = s))