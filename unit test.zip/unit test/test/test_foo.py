from unittest import TestCase, main
from main import foo

class TestFoo(TestCase):

    def test_foo(self):
        self.assertEqual(foo(1), 0.5)
        self.assertEqual(foo(0), 1)
        self.assertEqual(foo(4), 0.2)

    def test_types(self):
        self.assertRaises(TypeError, foo, [2, 3])
        self.assertRaises(TypeError, foo, [2])
        self.assertRaises(TypeError, foo, 2+3j)
        self.assertRaises(TypeError, foo, 'seven')
        self.assertRaises(TypeError, foo, True)




if __name__ == '__main__':
    main()